[Oboe Docs Home](https://github.com/google/oboe/blob/master/docs/README.md)

# Oboe Tech Notes

* [Using Audio Effects with Oboe](effects.md)
* [Disconnected Streams](disconnect.md) - Responding to Plugging In and Unplugging Headsets
* [Assert in releaseBuffer()](rlsbuffer.md)
