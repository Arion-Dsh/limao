var searchData=
[
  ['patch',['Patch',['../structoboe_1_1_version.html#a690110f2b3e887892da8f29ab5c057b2',1,'oboe::Version']]],
  ['pause',['pause',['../classoboe_1_1_audio_stream.html#a04f29836748a8e5842aef2be200022ad',1,'oboe::AudioStream']]],
  ['performancemode',['PerformanceMode',['../namespaceoboe.html#a1068781f3920654b1bfd7ed136468184',1,'oboe']]],
  ['powersaving',['PowerSaving',['../namespaceoboe.html#a1068781f3920654b1bfd7ed136468184abbad080463ed11f9d77797c04aa1e5b1',1,'oboe']]]
];
