var searchData=
[
  ['oboe',['oboe',['../namespaceoboe.html',1,'']]],
  ['oboeglobals',['OboeGlobals',['../classoboe_1_1_oboe_globals.html',1,'oboe']]],
  ['onaudioready',['onAudioReady',['../classoboe_1_1_audio_stream_data_callback.html#ad8a3a9f609df5fd3a5d885cbe1b2204d',1,'oboe::AudioStreamDataCallback::onAudioReady()'],['../classoboe_1_1_stabilized_callback.html#ad447e12ebf732cf151655c1fbaf58a49',1,'oboe::StabilizedCallback::onAudioReady()']]],
  ['ondefaultcallback',['onDefaultCallback',['../classoboe_1_1_audio_stream.html#a0ea79e60f5a3d29fc5a1a116aba11dfe',1,'oboe::AudioStream']]],
  ['onerror',['onError',['../classoboe_1_1_audio_stream_error_callback.html#a5ad4b8936746ecbb2160a9389b117fc3',1,'oboe::AudioStreamErrorCallback']]],
  ['onerrorafterclose',['onErrorAfterClose',['../classoboe_1_1_audio_stream_error_callback.html#a76bd3ef3e00396e10c21812003654cfe',1,'oboe::AudioStreamErrorCallback::onErrorAfterClose()'],['../classoboe_1_1_stabilized_callback.html#af7521da42c4b08a71e6102994f6f41f4',1,'oboe::StabilizedCallback::onErrorAfterClose()']]],
  ['onerrorbeforeclose',['onErrorBeforeClose',['../classoboe_1_1_audio_stream_error_callback.html#a4eb1e4916b71d8231e97b19898bc9bf0',1,'oboe::AudioStreamErrorCallback::onErrorBeforeClose()'],['../classoboe_1_1_stabilized_callback.html#a7ec0e9fca3181962ab78716bcda83e10',1,'oboe::StabilizedCallback::onErrorBeforeClose()']]],
  ['open',['open',['../classoboe_1_1_audio_stream.html#a686c6ce8a29051c858fd1de386805dc6',1,'oboe::AudioStream']]],
  ['openmanagedstream',['openManagedStream',['../classoboe_1_1_audio_stream_builder.html#a7ab172a9be4fca2489aa5cbcc48c20ff',1,'oboe::AudioStreamBuilder']]],
  ['opensles',['OpenSLES',['../namespaceoboe.html#a92972414867c81d5974cb2ed7abefbf6a24e758ea9c1e842ef71cc8ff8b63fa9b',1,'oboe']]],
  ['openstream',['openStream',['../classoboe_1_1_audio_stream_builder.html#a86b94cfa47729bef2e04dce1a9086074',1,'oboe::AudioStreamBuilder::openStream(AudioStream **stream)'],['../classoboe_1_1_audio_stream_builder.html#a44b68216c48f8fb08a9e63178e0b0eeb',1,'oboe::AudioStreamBuilder::openStream(std::shared_ptr&lt; oboe::AudioStream &gt; &amp;stream)']]],
  ['operator_20_21',['operator !',['../classoboe_1_1_result_with_value.html#a6fb3c61c5716a045ba48dc5a5dfc8169',1,'oboe::ResultWithValue']]],
  ['operator_20bool',['operator bool',['../classoboe_1_1_result_with_value.html#ae32b1953b777af7d1d0c94862ca39986',1,'oboe::ResultWithValue']]],
  ['operator_20result',['operator Result',['../classoboe_1_1_result_with_value.html#af62107817c0bc76047e6b655a78504ba',1,'oboe::ResultWithValue']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../namespaceoboe.html#aa403103686222502d1cfc47bafc10aeb',1,'oboe']]],
  ['operator_3d',['operator=',['../classoboe_1_1_audio_stream_base.html#aa9c987a59555d7a60b9f7a63f4afc7fc',1,'oboe::AudioStreamBase']]],
  ['output',['Output',['../namespaceoboe.html#af2147500089212955498a08ef2edb5aea29c2c02a361c9d7028472e5d92cd4a54',1,'oboe']]]
];
