var searchData=
[
  ['oboeglobals',['OboeGlobals',['../classoboe_1_1_oboe_globals.html',1,'oboe']]]
];
