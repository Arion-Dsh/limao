var searchData=
[
  ['calculatelatencymillis',['calculateLatencyMillis',['../classoboe_1_1_audio_stream.html#ae023cb001f3261d064f423101798d6be',1,'oboe::AudioStream']]],
  ['close',['close',['../classoboe_1_1_audio_stream.html#a9c8ea30e30e513766d5e996c370eb8d8',1,'oboe::AudioStream']]],
  ['convertfloattopcm16',['convertFloatToPcm16',['../namespaceoboe.html#adbda063116feb9fa98a31ee820170060',1,'oboe']]],
  ['convertformattosizeinbytes',['convertFormatToSizeInBytes',['../namespaceoboe.html#ac67383a3df0f6e7a51f8415ffd9fdaca',1,'oboe']]],
  ['convertpcm16tofloat',['convertPcm16ToFloat',['../namespaceoboe.html#ad17bee42828d13f2ef62a889e175c643',1,'oboe']]],
  ['converttotext',['convertToText',['../namespaceoboe.html#af65aaea3c5d82eee6906664d61c094b3',1,'oboe']]],
  ['createbasedonsign',['createBasedOnSign',['../classoboe_1_1_result_with_value.html#a2304c6120e2aad8f2189383a98c7b0a7',1,'oboe::ResultWithValue']]]
];
