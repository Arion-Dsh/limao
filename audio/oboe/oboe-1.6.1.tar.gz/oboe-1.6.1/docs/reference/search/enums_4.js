var searchData=
[
  ['performancemode',['PerformanceMode',['../namespaceoboe.html#a1068781f3920654b1bfd7ed136468184',1,'oboe']]]
];
