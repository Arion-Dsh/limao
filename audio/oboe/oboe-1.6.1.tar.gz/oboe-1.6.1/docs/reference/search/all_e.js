var searchData=
[
  ['read',['read',['../classoboe_1_1_audio_stream.html#a8089f0a0cb68d4039cf33e6584129978',1,'oboe::AudioStream']]],
  ['requestflush',['requestFlush',['../classoboe_1_1_audio_stream.html#a6bd5d633ff999e4da1faf3cd949aa602',1,'oboe::AudioStream']]],
  ['requestpause',['requestPause',['../classoboe_1_1_audio_stream.html#a7f18bb3cc5490fd7fbc1f6da63c730f6',1,'oboe::AudioStream']]],
  ['requestreset',['requestReset',['../classoboe_1_1_latency_tuner.html#a6c0142e08dc65eda8f758b4794450867',1,'oboe::LatencyTuner']]],
  ['requeststart',['requestStart',['../classoboe_1_1_audio_stream.html#a3c484e314dee8dfed1d419f487b5d601',1,'oboe::AudioStream']]],
  ['requeststop',['requestStop',['../classoboe_1_1_audio_stream.html#a820e634f741e6b5efdcef8104cecb919',1,'oboe::AudioStream']]],
  ['result',['Result',['../namespaceoboe.html#a486512e787b609c80ba4436f23929af1',1,'oboe']]],
  ['resultwithvalue',['ResultWithValue',['../classoboe_1_1_result_with_value.html',1,'oboe::ResultWithValue&lt; T &gt;'],['../classoboe_1_1_result_with_value.html#aae75caa0d16a9e23a012f77fb50c5927',1,'oboe::ResultWithValue::ResultWithValue(oboe::Result error)'],['../classoboe_1_1_result_with_value.html#a600309367db58d71f0ec16e90f7ebea5',1,'oboe::ResultWithValue::ResultWithValue(T value)']]]
];
