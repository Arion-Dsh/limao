var searchData=
[
  ['framesperburst',['FramesPerBurst',['../classoboe_1_1_default_stream_values.html#ab5ea5576699cebc56193f5c297d3e300',1,'oboe::DefaultStreamValues']]]
];
